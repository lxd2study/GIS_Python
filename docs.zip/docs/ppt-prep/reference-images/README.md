# 参考图目录说明

这个目录用于给答辩 PPT 预留参考图。

## 建议子目录

```text
reference-images/
├── cover/          # 封面或结束页使用的风格参考图
├── architecture/   # 架构图风格参考
├── workflow/       # 流程图风格参考
├── ui/             # 真实系统界面截图
└── results/        # 真彩色、NDVI、云掩膜、镶嵌等结果图
```

## 使用建议

- `cover/`：放 1-2 张你想要的封面风格图，用于统一整套 PPT 的视觉语言。
- `architecture/`：放你认可的学术架构图截图或示意图，用于约束生成风格。
- `workflow/`：放流程图样式参考，避免生成出来过于花哨。
- `ui/`：优先放真实项目截图。
- `results/`：放系统跑出来的典型结果图。

## 命名建议

```text
cover-01.jpg
architecture-01.png
workflow-01.png
ui-single-task-01.png
ui-batch-01.png
result-true-color-01.png
result-ndvi-01.png
result-cloud-mask-01.png
result-mosaic-01.png
```
